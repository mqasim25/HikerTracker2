package com.example.hikertracker.Adapter;



import com.example.hikertracker.Adapter.ExpandRecycler.LocaIcon;
import com.example.hikertracker.Models.Locations;
import com.example.hikertracker.R;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class LocationExpand {

    /*public static List<LocaIcon> makeHeaders(String timeStampStr, ArrayList<Locations> locationsArrayList) {
        return Collections.singletonList(makeTimeStamps(timeStampStr, locationsArrayList));
    }*/

    /*public static LocaIcon makeTimeStamps(String timeStamp, ArrayList<Locations> locationsArrayList) {

        return new LocaIcon(timeStamp, locationsArrayList, R.drawable.ic_arrow_down);
    }*/

}
