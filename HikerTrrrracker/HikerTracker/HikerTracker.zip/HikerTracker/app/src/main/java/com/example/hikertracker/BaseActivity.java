package com.example.hikertracker;

import android.content.SharedPreferences;

public class BaseActivity {

    public static SharedPreferences sharedData;
    public static SharedPreferences.Editor sharedEditor;


}

