package com.example.hikertracker.Models;

public class Email {

    String emailaddress;

    public Email() {

    }

    public Email(String emailaddress) {
        this.emailaddress = emailaddress;
    }

    public String getEmailaddress() {
        return emailaddress;
    }

    public void setEmailaddress(String emailaddress) {
        this.emailaddress = emailaddress;
    }
}
