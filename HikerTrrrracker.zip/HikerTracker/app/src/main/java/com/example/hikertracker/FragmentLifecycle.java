package com.example.hikertracker;

public interface FragmentLifecycle {

    public void onPauseFragment();
    public void onResumeFragment();

}